from setuptools import setup

min_pandas_ver = "1.1.0"


setup(name='dfs',
      version='1.1.1',
      author="Shafin M",
      author_email="shafinmohammed071@gmail.com",
      description='DataFrame Services built on top of Pandas and Numpy',
      packages=['dfs'],
      zip_safe=False,
      install_requires = [ f'pandas' ],
      setup_requires = [ f'pandas' ],
      )


