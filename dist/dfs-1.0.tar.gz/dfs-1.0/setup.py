from setuptools import setup

setup(name='dfs',
      version='1.0',
      author="Shafin M",
      author_email="shafinmohammed071@gmail.com",
      description='DataFrame Services built on top of Pandas and Numpy',
      packages=['dfs'],
      zip_safe=False)