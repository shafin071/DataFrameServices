from setuptools import setup

setup(name='dfs',
      version='1.1',
      author="Shafin M",
      author_email="shafinmohammed071@gmail.com",
      description='DataFrame Services built on top of Pandas and Numpy',
      packages=['dfs'],
      install_requires=[
                'pandas',
                'numpy',
            ],
      zip_safe=False)